load("config.js");

function execute() {
  var response = fetch(API_URL + "/manga/tag");
  if (response.ok) {
    var data = response.json();
    var genres = [];
    for (var i = 0; i < data.data.length; i++) {
      var tag = data.data[i];
      genres.push({
        title: getTitle(tag.attributes.name),
        input: tag.id,
        script: "genrecontent.js",
      });
    }
    genres.sort(function (a, b) {
      return a.title.localeCompare(b.title);
    });
    return Response.success(genres);
  }
  return Response.error("Không thể tải thể loại");
}
