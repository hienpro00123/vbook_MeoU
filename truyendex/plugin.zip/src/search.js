load("config.js");

function execute(key, page) {
  if (!page) page = "0";
  var offset = parseInt(page) || 0;

  var response = fetch(API_URL + "/manga?title=" + encodeURIComponent(key) + "&limit=20&offset=" + offset + "&includes[]=cover_art&availableTranslatedLanguage[]=vi&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica&order[relevance]=desc");
  if (response.ok) {
    var data = response.json();
    var books = parseMangaList(data);
    var next = null;
    if (data.offset + data.limit < data.total) {
      next = String(data.offset + data.limit);
    }
    return Response.success(books, next);
  }
  return Response.error("Không thể tìm kiếm");
}
