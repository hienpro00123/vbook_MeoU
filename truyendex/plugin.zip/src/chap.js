load("config.js");

function execute(url) {
  var chapterId = extractUUID(url);
  var response = fetch(API_URL + "/at-home/server/" + chapterId + "?forcePort443=true");
  if (response.ok) {
    var data = response.json();
    if (!data || !data.chapter) return Response.error("Dữ liệu chương không hợp lệ");
    var images = [];
    var baseUrl = data.baseUrl || IMAGE_CDN;
    var hash = data.chapter.hash;
    var pages = data.chapter.data;
    if (!pages || pages.length === 0) {
      pages = data.chapter.dataSaver;
    }
    if (!pages || pages.length === 0) return Response.error("Không có ảnh");
    for (var i = 0; i < pages.length; i++) {
      var imgUrl = baseUrl + "/data/" + hash + "/" + pages[i];
      images.push({
        link: proxyImage(imgUrl),
      });
    }
    return Response.success(images);
  }
  return Response.error("Không thể tải nội dung chương");
}
