load("config.js");

function execute(url) {
  var response = fetch(url);
  if (!response.ok) return Response.error("Không thể tải mục lục");

  var data = response.json();
  var chapters = [];
  if (!data.data || data.data.length === 0) return Response.success(chapters);

  for (var i = 0; i < data.data.length; i++) {
    var item = data.data[i];
    if (item.type !== "chapter") continue;
    var attr = item.attributes;
    var title = "";
    if (attr.volume) title += "T" + attr.volume + " ";
    if (attr.chapter) {
      title += "Ch. " + attr.chapter;
    }
    if (attr.title) {
      title += (title ? " - " : "") + attr.title;
    }
    if (!title) title = "Oneshot";

    chapters.push({
      name: title,
      url: item.id,
    });
  }

  return Response.success(chapters);
}
