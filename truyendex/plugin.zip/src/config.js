var BASE_URL = "https://truyendex.cc";
var API_URL = "https://api.mangadex.org";
var COVER_BASE = "https://mangadex.org/covers";
var IMAGE_CDN = "https://uploads.mangadex.org";
var PROXY_URL = "https://services.f-ck.me/v1/image/";
var LANGUAGE = "vi";

function toBase64(str) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var result = "";
  for (var i = 0; i < str.length; i += 3) {
    var a = str.charCodeAt(i);
    var b = (i + 1 < str.length) ? str.charCodeAt(i + 1) : 0;
    var c = (i + 2 < str.length) ? str.charCodeAt(i + 2) : 0;
    result += chars.charAt((a >> 2) & 63);
    result += chars.charAt(((a & 3) << 4) | ((b >> 4) & 15));
    result += (i + 1 < str.length) ? chars.charAt(((b & 15) << 2) | ((c >> 6) & 3)) : "=";
    result += (i + 2 < str.length) ? chars.charAt(c & 63) : "=";
  }
  return result;
}

function proxyImage(url) {
  return PROXY_URL + toBase64(url);
}

function getTitle(titleObj) {
  if (!titleObj) return "";
  if (titleObj[LANGUAGE]) return titleObj[LANGUAGE];
  var keys = Object.keys(titleObj);
  if (keys.length > 0) return titleObj[keys[0]];
  return "";
}

function getDescription(descObj) {
  if (!descObj) return "";
  if (descObj[LANGUAGE]) return descObj[LANGUAGE];
  if (descObj["en"]) return descObj["en"];
  var keys = Object.keys(descObj);
  if (keys.length > 0) return descObj[keys[0]];
  return "";
}

function getCoverUrl(mangaId, relationships, size) {
  if (!relationships) return "";
  for (var i = 0; i < relationships.length; i++) {
    var rel = relationships[i];
    if (rel.type === "cover_art" && rel.attributes && rel.attributes.fileName) {
      var url = COVER_BASE + "/" + mangaId + "/" + rel.attributes.fileName + "." + (size || "256") + ".jpg";
      return proxyImage(url);
    }
  }
  return "";
}

function getAuthor(relationships) {
  if (!relationships) return "";
  for (var i = 0; i < relationships.length; i++) {
    if (relationships[i].type === "author" && relationships[i].attributes) {
      return relationships[i].attributes.name;
    }
  }
  return "";
}

function extractUUID(url) {
  var match = /([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/i.exec(url);
  return match ? match[1] : url;
}

function parseMangaList(data) {
  var books = [];
  if (!data || !data.data) return books;
  for (var i = 0; i < data.data.length; i++) {
    var item = data.data[i];
    var mangaId = item.id;
    var cover = getCoverUrl(mangaId, item.relationships, "256");
    books.push({
      name: getTitle(item.attributes.title),
      link: "/nettrom/truyen-tranh/" + mangaId,
      host: BASE_URL,
      cover: cover,
    });
  }
  return books;
}
