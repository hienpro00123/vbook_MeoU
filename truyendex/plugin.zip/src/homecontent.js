load("config.js");

function execute(url, page) {
  if (!page) page = "0";
  var offset = parseInt(page) || 0;

  var response = fetch(url + "&limit=20&offset=" + offset);
  if (response.ok) {
    var data = response.json();
    var books = parseMangaList(data);
    var next = null;
    if (data.offset + data.limit < data.total) {
      next = String(data.offset + data.limit);
    }
    return Response.success(books, next);
  }
  return Response.error("Không thể tải dữ liệu");
}
