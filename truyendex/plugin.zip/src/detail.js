load("config.js");

function execute(url) {
  var mangaId = extractUUID(url);

  var response = fetch(API_URL + "/manga/" + mangaId + "?includes[]=artist&includes[]=author&includes[]=cover_art");
  if (response.ok) {
    var data = response.json();
    var attributes = data.data.attributes;
    var relationships = data.data.relationships;

    var cover = getCoverUrl(mangaId, relationships, "512");
    var author = getAuthor(relationships);

    var genres = [];
    if (attributes.tags) {
      for (var i = 0; i < attributes.tags.length; i++) {
        var tag = attributes.tags[i];
        genres.push({
          title: getTitle(tag.attributes.name),
          input: tag.id,
          script: "genrecontent.js",
        });
      }
    }

    var altTitles = "";
    if (attributes.altTitles) {
      var names = [];
      for (var j = 0; j < attributes.altTitles.length; j++) {
        var alt = attributes.altTitles[j];
        var altKeys = Object.keys(alt);
        if (altKeys.length > 0) names.push(alt[altKeys[0]]);
      }
      if (names.length > 0) altTitles = "Tên khác: " + names.join(", ");
    }

    return Response.success({
      name: getTitle(attributes.title),
      cover: cover,
      host: BASE_URL,
      author: author,
      description: getDescription(attributes.description),
      detail: altTitles,
      ongoing: attributes.status === "ongoing",
      genres: genres,
    });
  }
  return Response.error("Không thể tải thông tin truyện");
}
