load("config.js");

function execute(url) {
  var mangaId = extractUUID(url);
  var baseApiUrl = API_URL + "/manga/" + mangaId + "/feed?translatedLanguage[]=vi&order[volume]=asc&order[chapter]=asc&includes[]=scanlation_group";

  var response = fetch(baseApiUrl + "&limit=1&offset=0");
  if (response.ok) {
    var data = response.json();
    var total = data.total || 0;
    if (total === 0) return Response.success([]);

    var pages = [];
    for (var offset = 0; offset < total; offset += 96) {
      pages.push(baseApiUrl + "&limit=96&offset=" + offset);
    }
    return Response.success(pages);
  }
  return Response.error("Không thể tải mục lục");
}
