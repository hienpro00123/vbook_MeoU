load("config.js");

function execute() {
  return Response.success([
    {
      title: "Mới cập nhật",
      input: API_URL + "/manga?includes[]=cover_art&availableTranslatedLanguage[]=vi&order[latestUploadedChapter]=desc&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica",
      script: "homecontent.js",
    },
    {
      title: "Đánh giá cao",
      input: API_URL + "/manga?includes[]=cover_art&availableTranslatedLanguage[]=vi&order[rating]=desc&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica",
      script: "homecontent.js",
    },
    {
      title: "Theo dõi nhiều",
      input: API_URL + "/manga?includes[]=cover_art&availableTranslatedLanguage[]=vi&order[followedCount]=desc&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica",
      script: "homecontent.js",
    },
  ]);
}
