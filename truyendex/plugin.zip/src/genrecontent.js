load("config.js");

function execute(url, page) {
  if (!page) page = "0";
  var offset = parseInt(page) || 0;

  var response = fetch(API_URL + "/manga?includes[]=cover_art&includedTags[]=" + url + "&availableTranslatedLanguage[]=vi&order[followedCount]=desc&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica&limit=20&offset=" + offset);
  if (response.ok) {
    var data = response.json();
    var books = parseMangaList(data);
    var next = null;
    if (data.offset + data.limit < data.total) {
      next = String(data.offset + data.limit);
    }
    return Response.success(books, next);
  }
  return Response.error("Không thể tải dữ liệu");
}
