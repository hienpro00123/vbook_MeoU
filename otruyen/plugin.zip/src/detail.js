load("config.js");

function execute(url) {
  var response = fetch(BASE_URL + "/truyen-tranh/" + extractSlug(url));
  if (response.ok) {
    var json = response.json();
    var data = json.data;
    var item = data.item;
    var cdnImage = data.APP_DOMAIN_CDN_IMAGE;

    var thumb = resolveThumb(item.thumb_url, cdnImage);
    var authorName = joinArray(item.author);
    var originName = joinArray(item.origin_name);

    var genres = parseGenres(item.category);

    var description = stripHtml(item.content);

    var details = [];
    if (originName) details.push("Tên khác: " + originName);
    if (item.status && STATUS_MAP[item.status]) details.push("Trạng thái: " + STATUS_MAP[item.status]);

    return Response.success({
      name: item.name,
      cover: thumb,
      host: HOST,
      author: authorName,
      description: description,
      detail: details.join("\n"),
      ongoing: item.status === "ongoing",
      genres: genres,
      suggests: genres.length > 0 ? [{ title: "Truyện cùng thể loại", input: genres[0].input, script: "suggest.js" }] : [],
    });
  }
  return Response.error("Không thể tải thông tin truyện");
}
