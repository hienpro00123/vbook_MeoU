var BASE_URL = DOMAIN || "https://novel.cooks.tw";
var API_BASE = BASE_URL + "/api";

function fetchApi(path) {
    var sep = path.indexOf("?") >= 0 ? "&" : "?";
    var url = API_BASE + path + sep + "lang=zh-TW";
    var res = fetch(url, {
        headers: {
            "Referer": BASE_URL,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
    });
    if (!res || !res.ok) return null;
    try { return res.json(); } catch(e) { return null; }
}

function coverUrl(id) {
    var n = parseInt(id);
    return "https://pic.cooks.tw/" + Math.floor(n / 1000) + "/" + n + "/" + n + "s.jpg";
}

function makeChapUrl(articleId, chapterId) {
    return BASE_URL + "/reader.html?articleid=" + articleId + "&chapterid=" + chapterId;
}

function parseArticleId(url) {
    var m = url.match(/[?&]articleid=(\d+)/);
    return m ? m[1] : null;
}

function parseChapterId(url) {
    var m = url.match(/[?&]chapterid=(\d+)/);
    return m ? m[1] : null;
}

function buildItems(items, limit) {
    var r = [], len = (limit && limit < items.length) ? limit : items.length;
    for (var i = 0; i < len; i++) {
        var n = items[i];
        var articleId = n.articleid || n.my_novel_id || "";
        if (!articleId) continue;
        r.push({
            name: n.articlename || n.title || "",
            link: BASE_URL + "/novel.html?articleid=" + articleId,
            host: BASE_URL,
            cover: coverUrl(articleId),
            description: n.intro || n.author || ""
        });
    }
    return r;
}

function textToHtml(text) {
    if (!text) return "";
    var lines = text.split(/\r?\n/);
    var html = "";
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (line) html += "<p>" + line + "</p>";
    }
    return html;
}
