load("config.js");
function execute(sortid, page) {
    var p = parseInt(page) || 1;
    var json = fetchApi("/novel/list?sortid=" + sortid + "&page=" + p + "&limit=20");
    if (!json || json.code !== 200) return Response.error("Tải danh sách thất bại");
    var d = json.data;
    if (!d) return Response.error("Không có dữ liệu");
    // Hỗ trợ cả d.items lẫn d.data (tuỳ phiên bản API)
    var items = d.items || d.data;
    if (!items) return Response.error("Không có dữ liệu thể loại");
    var next = d.next_page ? String(p + 1) : null;
    return Response.success(buildItems(items), next);
}
