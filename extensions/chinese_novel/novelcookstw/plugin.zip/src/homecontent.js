load("config.js");
function execute(url, page) {
    var path = url || "/novel/hot";
    var json = fetchApi(path);
    if (!json || json.code !== 200) return Response.error("Tải danh sách thất bại");
    if (!json.data) return Response.error("Không có dữ liệu");
    return Response.success(buildItems(json.data));
}
