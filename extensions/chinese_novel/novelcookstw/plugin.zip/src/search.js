load("config.js");
function execute(key, page) {
    var p = parseInt(page) || 1;
    var json = fetchApi("/novel/search?q=" + encodeURIComponent(key) + "&page=" + p + "&limit=20");
    if (!json || json.code !== 200) return Response.error("Tìm kiếm thất bại");
    var d = json.data;
    if (!d || !d.items) return Response.error("Không có kết quả");
    var total = d.total || 0;
    var hasNext = total > p * 20;
    var next = hasNext ? String(p + 1) : null;
    return Response.success(buildItems(d.items), next);
}
