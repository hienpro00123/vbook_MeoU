load("config.js");

function execute(url, page) {
    var p = page ? parseInt(page) : 1;
    var fetchUrl = BASE_URL + "/" + url + "/";
    if (p > 1) fetchUrl = BASE_URL + "/" + url + "/page/" + p + "/";
    var doc = fetchDoc(fetchUrl);
    if (!doc) return Response.error("");
    var items = parseList(doc);
    if (!items || items.length === 0) return Response.success([], null);
    var nextLink = selFirst(doc, ".uk-pagination a[rel='next'], a.next");
    var next = nextLink ? String(p + 1) : null;
    return Response.success(items, next);
}
