var NOVEL_SEARCH_ALIAS_MAP = {
    "dau pha thuong khung": "斗破苍穹",
    "pham nhan tu tien": "凡人修仙传",
    "tien nghich": "仙逆",
    "dai chua te": "大主宰",
    "vo dong can khon": "武动乾坤",
    "the gioi hoan my": "完美世界",
    "than mo": "神墓",
    "toan chuc phap su": "全职法师",
    "tinh than bien": "星辰变",
    "nguyen ton": "元尊",
    "nhat niem vinh hang": "一念永恒",
    "quy bi chi chu": "诡秘之主",
    "toan chuc cao thu": "全职高手",
    "tru tien": "诛仙",
    "kiem lai": "剑来",
    "de ba": "帝霸",
    "dau la dai luc": "斗罗大陆",
    "vo luyen dinh phong": "武炼巅峰",
    "van co than de": "万古神帝",
    "than an vuong toa": "神印王座",
    "tu la vo than": "修罗武神",
    "do thi": "都市",
    "than dao dan ton": "神道丹尊",
    "bat hu pham nhan": "不朽凡人",
    "cau ma": "求魔",
    "nga duc phong thien": "我欲封天",
    "tuyet ung linh chu": "雪鹰领主",
    "dai phung da canh nhan": "大奉打更人",
    "co chan nhan": "蛊真人",
    "thanh khu": "圣墟",
    "linh vu thien ha": "灵武天下",
    "truong sinh gioi": "长生界",
    "xich tam tuan thien": "赤心巡天",
    "su huynh ta thuc tai qua on trong": "我师兄实在太稳健了",
    "tu chan lieu thien quan": "修真聊天群",
    "gia thien": "遮天",
    "thon phe tinh khong": "吞噬星空",
    "ban long": "盘龙",
    "tuong da": "将夜",
    "khanh du nien": "庆余年",
    "tuyet trung han dao hanh": "雪中悍刀行",
    "muc than ky": "牧神记",
    "thien khai du bao": "天启预报",
    "dao quy di tien": "道诡异仙",
    "chu te": "赘婿",
    "minh trieu bai gia tu": "明朝败家子"
};
var NOVEL_SEARCH_OFFLINE_OVERRIDES = {
    "tien hiep": "仙俠",
    "tu tien": "修仙",
    "xuyen khong": "穿越",
    "xuyen nhanh": "快穿",
    "trong sinh": "重生",
    "ma phap": "魔法",
    "phieu luu": "冒險",
    "huyen huyen": "玄幻",
    "tu chan": "修真",
    "he thong": "系統",
    "tinh cam": "言情",
    "ngon tinh": "言情",
    "ngon tinh co dai": "古代言情",
    "ngon tinh hien dai": "現代言情",
    "nu chinh": "女主",
    "nu chinh manh": "女強",
    "nam chinh": "男主",
    "nam chinh ba dao": "霸道男主",
    "ba dao": "霸道",
    "co dai": "古代",
    "hien dai": "現代",
    "dam my": "耽美",
    "bach hop": "百合",
    "phan phai": "反派",
    "vo dich": "無敵",
    "sang van": "爽文",
    "kiem hiep": "武俠",
    "hoan thanh": "完結",
    "dang ra": "連載",
    "full": "完結"
};
var NOVEL_SEARCH_TRANSLATION_TTL = 300000;
var NOVEL_SEARCH_TRANSLATION_ERROR_TTL = 300000;
var NOVEL_SEARCH_TRANSLATION_RETRY_TTL = 10000;
var NOVEL_SEARCH_TRANSLATION_TIMEOUT = 8000;

function novelSearchNormalize(text) {
    return String(text || "").toLowerCase()
        .replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g, "a")
        .replace(/[èéẹẻẽêềếệểễ]/g, "e")
        .replace(/[ìíịỉĩ]/g, "i")
        .replace(/[òóọỏõôồốộổỗơờớợởỡ]/g, "o")
        .replace(/[ùúụủũưừứựửữ]/g, "u")
        .replace(/[ỳýỵỷỹ]/g, "y")
        .replace(/đ/g, "d")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9\s]/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}

function novelSearchIsVietnamese(text) {
    if (/[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i.test(text)) {
        return true;
    }
    return /(^|\s)(tim kiem truyen|tim truyen|doc truyen|tim kiem|truyen|doc|tac gia|the loai|tieu thuyet|chuong|hoan thanh|dang ra|full|tien hiep|tu tien|xuyen khong|xuyen nhanh|trong sinh|ma phap|phieu luu|huyen huyen|tu chan|he thong|tinh cam|ngon tinh|nu chinh|nam chinh|co dai|hien dai|dam my|bach hop|phan phai|vo dich|sang van|kiem hiep|ba dao)(\s|$)/.test(novelSearchNormalize(text));
}

function novelSearchResolveQuery(text) {
    var key = novelSearchNormalize(text);
    var alias = novelSearchFindAlias(key);
    if (alias) return { query: alias };
    if (!novelSearchIsVietnamese(text)) return { query: text };

    var translationText = novelSearchPrepareTranslation(text);
    var translationKey = novelSearchNormalize(translationText);
    if (translationText.length > 100) return { error: "Từ khóa tiếng Việt quá dài để dịch" };

    var cacheKey = "novelcookstw:search-translation:v5:" + encodeURIComponent(translationKey);
    try {
        var cached = parseJson(cacheStorage.getItem(cacheKey));
        if (cached && cached.expires > Date.now()) {
            if (cached.query) return { query: cached.query };
            if (cached.error) return { error: cached.error };
        }
    } catch (e) {
        if (typeof Log !== "undefined") Log.log("NovelCooksTW translation cache read failed: " + e);
    }

    var offlineQuery = novelSearchTranslateOffline(translationText);
    if (offlineQuery) {
        try {
            cacheStorage.setItem(cacheKey, JSON.stringify({
                expires: Date.now() + NOVEL_SEARCH_TRANSLATION_TTL,
                query: offlineQuery
            }));
        } catch (e2) {
            if (typeof Log !== "undefined") Log.log("NovelCooksTW offline translation cache write failed: " + e2);
        }
        return { query: offlineQuery };
    }

    var cooldownKey = "novelcookstw:search-translation:google-429";
    try {
        var cooldown = parseJson(cacheStorage.getItem(cooldownKey));
        if (cooldown && cooldown.expires > Date.now()) {
            return { error: "Google Translate đang giới hạn yêu cầu (HTTP 429). Thử lại sau hoặc tìm bằng tên tiếng Trung." };
        }
    } catch (e3) {
        if (typeof Log !== "undefined") Log.log("NovelCooksTW translation cooldown read failed: " + e3);
    }

    var transientCooldownKey = "novelcookstw:search-translation:google-transient";
    try {
        var transientCooldown = parseJson(cacheStorage.getItem(transientCooldownKey));
        if (transientCooldown && transientCooldown.expires > Date.now()) {
            return { error: "Google Translate đang tạm lỗi kết nối. Thử lại sau hoặc tìm bằng tên tiếng Trung." };
        }
    } catch (e4) {
        if (typeof Log !== "undefined") Log.log("NovelCooksTW transient cooldown read failed: " + e4);
    }

    var translated = novelSearchTranslateWithGoogle(translationText);
    if (translated.error && translated.error.indexOf("HTTP 429") >= 0) {
        translated.error = "Google Translate đang giới hạn yêu cầu (HTTP 429). Thử lại sau hoặc tìm bằng tên tiếng Trung.";
        try {
            cacheStorage.setItem(cooldownKey, JSON.stringify({
                expires: Date.now() + NOVEL_SEARCH_TRANSLATION_ERROR_TTL
            }));
        } catch (e5) {
            if (typeof Log !== "undefined") Log.log("NovelCooksTW translation cooldown write failed: " + e5);
        }
    } else if (translated.error && (translated.status === 0 || translated.status >= 500)) {
        try {
            cacheStorage.setItem(transientCooldownKey, JSON.stringify({
                expires: Date.now() + NOVEL_SEARCH_TRANSLATION_RETRY_TTL
            }));
        } catch (e6) {
            if (typeof Log !== "undefined") Log.log("NovelCooksTW transient cooldown write failed: " + e6);
        }
    }
    try {
        if (translated.query) {
            cacheStorage.setItem(cacheKey, JSON.stringify({
                expires: Date.now() + NOVEL_SEARCH_TRANSLATION_TTL,
                query: translated.query
            }));
        } else if (translated.error) {
            var errorTtl = translated.error.indexOf("HTTP 429") >= 0
                ? NOVEL_SEARCH_TRANSLATION_ERROR_TTL
                : NOVEL_SEARCH_TRANSLATION_RETRY_TTL;
            cacheStorage.setItem(cacheKey, JSON.stringify({
                expires: Date.now() + errorTtl,
                error: translated.error
            }));
        }
    } catch (e7) {
        if (typeof Log !== "undefined") Log.log("NovelCooksTW translation cache write failed: " + e7);
    }
    return translated;
}

function novelSearchTranslateOffline(text) {
    var words = novelSearchNormalize(text).split(" ");
    var output = "";
    var index = 0;
    while (index < words.length) {
        var match = "";
        var translated = "";
        var maxLength = words.length - index;
        if (maxLength > 7) maxLength = 7;
        for (var length = maxLength; length > 0; length--) {
            var phrase = words.slice(index, index + length).join(" ");
            if (NOVEL_SEARCH_OFFLINE_OVERRIDES[phrase]) {
                match = phrase;
                translated = NOVEL_SEARCH_OFFLINE_OVERRIDES[phrase];
                break;
            }
            if (NOVEL_SEARCH_OFFLINE_DICTIONARY[phrase]) {
                match = phrase;
                translated = NOVEL_SEARCH_OFFLINE_DICTIONARY[phrase];
                break;
            }
        }
        if (!match) return "";
        output += translated;
        index += match.split(" ").length;
    }
    return output;
}

function novelSearchPrepareTranslation(text) {
    var value = String(text || "").trim();
    for (var i = 0; i < 3; i++) {
        var trimmed = value
            .replace(/^(tìm kiếm truyện|tim kiem truyen|tìm truyện|tim truyen|đọc truyện|doc truyen|thể loại truyện|the loai truyen|thể loại|the loai|truyện|truyen|tìm kiếm|tim kiem|tìm|tim|đọc|doc)\s+/i, "")
            .trim();
        if (trimmed && trimmed !== value) {
            value = trimmed;
            continue;
        }

        trimmed = value
            .replace(/\s+(truyện\s+(full|hoàn thành|hoan thanh|hay nhất|hay nhat|mới nhất|moi nhat)|full|hoàn thành|hoan thanh|hay nhất|hay nhat|mới nhất|moi nhat)$/i, "")
            .trim();
        if (!trimmed || trimmed === value) break;
        value = trimmed;
    }
    return value || String(text || "").trim();
}

function novelSearchFindAlias(key) {
    var alias = NOVEL_SEARCH_ALIAS_MAP[key];
    if (alias) return alias;

    var titleKey = key;
    for (var i = 0; i < 3; i++) {
        var trimmed = titleKey
            .replace(/^(tim kiem truyen|tim truyen|doc truyen|tim kiem|tim|doc|truyen)\s+/, "")
            .replace(/\s+(truyen|full|hoan thanh|hoan|hay nhat|hay|moi)$/, "")
            .trim();
        if (trimmed === titleKey) break;
        titleKey = trimmed;
    }
    return NOVEL_SEARCH_ALIAS_MAP[titleKey] || "";
}

function novelSearchTranslateWithGoogle(text) {
    var url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=vi&tl=zh-CN&dt=t&q=" +
        encodeURIComponent(text);
    var response = null;
    try {
        response = fetch(url, { timeout: NOVEL_SEARCH_TRANSLATION_TIMEOUT });
    } catch (e) {
        return { error: "Không kết nối được Google Translate: " + e, status: 0 };
    }
    if (!response || !response.ok) {
        return {
            error: "Google Translate trả HTTP " + (response ? response.status : 0),
            status: response ? response.status : 0
        };
    }

    var data;
    try {
        data = response.json();
    } catch (e2) {
        return { error: "Không đọc được phản hồi từ Google Translate", status: response.status };
    }
    var translated = "";
    var segments = data && data[0];
    if (segments && segments.length) {
        for (var i = 0; i < segments.length; i++) {
            if (segments[i] && segments[i][0]) translated += String(segments[i][0]);
        }
    }
    translated = translated.trim();
    if (/[\u3400-\u9fff]/.test(translated)) return { query: translated };
    return { error: "Google Translate không trả về từ khóa tiếng Trung", status: response.status };
}
