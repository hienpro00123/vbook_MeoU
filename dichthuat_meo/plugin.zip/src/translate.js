// Vietphrase Meo Translate
// Tu dien: name_dict.js (ten rieng), uuhoadich_dict.js (cum tu), vietphrase_dict.js (tu don)
// Moi tu dien la mang [[key, value], ...] sap xep tang dan theo do dai key
// -> ap dung nguoc (dai truoc, ngan sau) de tranh thay the nham

load("language_list.js");
load("name_dict.js");
load("uuhoadich_dict.js");
load("vietphrase_dict.js");

function execute(text, from, to, apiKey) {
    if (!text || text.length === 0) return Response.success("");
    var result = applyAll(text);
    return Response.success(result);
}

// ap dung ca 3 tu dien theo thu tu: ten rieng -> cum tu -> tu don
function applyAll(text) {
    text = applyDict(text, nameDict);
    text = applyDict(text, uuhoadichDict);
    text = applyDict(text, vietphraseDict);
    return text;
}

// ap dung mot tu dien: duyet nguoc (dai truoc) de tranh thay the nham
function applyDict(text, dict) {
    for (var i = dict.length - 1; i >= 0; i--) {
        var key = dict[i][0];
        var val = dict[i][1];
        if (text.indexOf(key) !== -1) {
            text = replaceAll(text, key, val);
        }
    }
    return text;
}

// thay the toan bo (khong dung regex de tranh loi ky tu dac biet)
function replaceAll(str, find, replace) {
    var result = "";
    var idx = str.indexOf(find);
    while (idx !== -1) {
        result += str.substring(0, idx) + replace;
        str = str.substring(idx + find.length);
        idx = str.indexOf(find);
    }
    return result + str;
}
